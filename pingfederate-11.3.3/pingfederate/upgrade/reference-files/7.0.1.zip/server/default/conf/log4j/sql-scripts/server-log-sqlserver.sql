# ------------------------------------------------------------
# Create table server_log
# ------------------------------------------------------------

CREATE TABLE server_log
(
	id         int NOT NULL IDENTITY (1, 1),
	dtime      datetime NULL,
    trackingid varchar(255) NULL,
    loglevel   varchar(8) NULL,
    classname  varchar(255) NULL,
    partnerid  varchar(255) NULL,
    username   varchar(255) NULL,
    message    varchar(MAX) NULL
)  ON [PRIMARY]
GO

