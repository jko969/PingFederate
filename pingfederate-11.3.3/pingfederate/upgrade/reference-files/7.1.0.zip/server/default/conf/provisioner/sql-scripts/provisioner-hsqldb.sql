-- Drop existing tables
--------------------------------------------------------------

DROP TABLE group_membership IF EXISTS;
DROP TABLE channel_group IF EXISTS;
DROP TABLE channel_user IF EXISTS;
DROP TABLE channel_variable IF EXISTS;


-- Table structure for table channel_variable
--------------------------------------------------------------

CREATE CACHED TABLE channel_variable (
  channel INTEGER,
  name VARCHAR(255),
  value VARCHAR(255),
  CONSTRAINT variablepk PRIMARY KEY (channel,name)
);


-- Table structure for table channel_user
--------------------------------------------------------------

CREATE CACHED TABLE channel_user (
  channel INT,
  dsGuid VARCHAR(255),
  saasGuid VARCHAR(255),
  saasUsername VARCHAR(255),
  valuesHash VARCHAR(32),
  inGroup INT,
  dirty INT,
  saasIdentity LONGVARCHAR,
  created TIMESTAMP,
  modified TIMESTAMP,
  CONSTRAINT saasusernameunique UNIQUE(channel,saasusername),
  CONSTRAINT userpk PRIMARY KEY (channel,dsguid)
);


-- Table structure for table channel_group
--------------------------------------------------------------

CREATE CACHED TABLE channel_group (
  channel INT,
  dsGuid VARCHAR(255),
  saasGuid VARCHAR(255),
  saasGroupName VARCHAR(255),
  valuesHash VARCHAR(32),
  inGroup INT,
  dirty INT,
  saasGroup LONGVARCHAR,
  created TIMESTAMP,
  modified TIMESTAMP,
  CONSTRAINT saasgroupnameunique UNIQUE(channel,saasgroupname),
  CONSTRAINT grouppk PRIMARY KEY (channel,dsguid)
);


-- Table structure for table group_membership
--------------------------------------------------------------

CREATE CACHED TABLE group_membership (
  channel INT,
  groupDsGuid VARCHAR(255),
  userDsGuid VARCHAR(255),
  CONSTRAINT membershipunique UNIQUE(channel,groupDsGuid,userDsGuid),
  CONSTRAINT membershipgroupfk FOREIGN KEY (channel,groupDsGuid) REFERENCES channel_group (channel,dsGuid) ON DELETE CASCADE,
  CONSTRAINT membershipuserfk FOREIGN KEY (channel,userDsGuid) REFERENCES channel_user (channel,dsGuid) ON DELETE CASCADE
);